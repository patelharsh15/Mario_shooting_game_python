# UI-2-
UI-2 Project

To play the game
Install pyjama library in python and install it in visual studio as well

Unzip the packages and in Vs code press Run  from the menu bar or go to main.py and press the small triangle button on the right side top corner
